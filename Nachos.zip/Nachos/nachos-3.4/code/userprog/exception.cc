// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

#define MAX_BUFFER 255
// tang program counter
void next_pc(){
    machine->registers[PrevPCReg] = machine->registers[PCReg]; // luu gia tri thanh ghi hien tai vao thanh ghi truoc do
    machine->registers[PCReg] = machine->registers[NextPCReg]; // dua thanh ghi hien tai len vi tri doan lenh ke tiep
    machine->registers[NextPCReg] += 4; // tang thanh ghi ke tiep len 4 byte de toi doan lenh tiep theo
}
// copy vung nho tu user kernel -> system kernel
// Input: dia chi vung nho o user kernel, chieu dai vung nho
// Output: dia chi vung nho sau khi copy tu user kernel o system kernel
char* User2System(int user_buffer, int length)
{
    char* kernel_buffer = new char[length + 1];
    if (kernel_buffer == NULL)
        return kernel_buffer;
    memset(kernel_buffer, 0, length + 1);
    // copy lan luot tung byte 1
    for (int i = 0; i < length; i++)
    {
        int oneChar = 0;
        machine->ReadMem(user_buffer + i, 1, &oneChar); // doc 1 byte o user buffer
        kernel_buffer[i] = (char)oneChar; // ghi 1 byte do vao kernel buffer
        if (oneChar == 0) // dung khi gap ki tu dung
            break;
    }
    return kernel_buffer;
}
// copy vung nho tu system kernel -> user kernel
// Input: dia chi vung nho o user kernel, chieu dai vung nho, dia chi vung nho o system kernel
// Output: chieu dai vung nho thuc su duoc copy sang user kernel
int System2User(int user_buffer, int len, char* kernel_buffer)
{
    if (len < 0) return -1;
    if (len == 0)return len;
    int i = 0;
    int oneChar = 0;
    // copy lan luot tung byte
    do{
        oneChar = (int)kernel_buffer[i]; // doc 1 byte ra oneChar
        machine->WriteMem(user_buffer + i, 1, oneChar); // ghi byte do ra user buffer
        i++;
    } while (i < len && oneChar != 0); // dung khi copy het vung nho hoac gap ki tu dung
    return i;
}
void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    switch(which){
    	case NoException:{
    		return;
    	}
    	case SyscallException:{
    		switch(type){
    			case SC_Halt:{
                    printf("Shutdown, initiated by user program. %d %d\n", which, type);
                    interrupt->Halt();
    			}
    			case SC_ReadInt:{
                    char* buffer = new char[MAX_BUFFER + 1]; // khoi tao buffer
    				int length = gSynchConsole->Read(buffer, MAX_BUFFER); // so byte thuc su doc duoc trong buffer
                    // kiem tra chieu dai va ki tu dau tien
    				if(length < 1 or (buffer[0] != '-' and (buffer[0] < '0' or buffer[0] > '9'))){
    					machine->WriteRegister(2, 0);
    					printf("\nThe integer number is not valid\n");
                        delete[] buffer;
                        next_pc();
                        return;
    				}
    				bool is_negative = buffer[0] == '-'; // kiem tra xem la so duong hay so am
    				int number = 0;
                    // lap qua tung chu so
    				for(char* ptr = buffer + (is_negative ? 1 : 0); *ptr != '\0'; ptr = ptr + 1){
                        // kiem tra cac ki tu hop le
    					if(*ptr < '0' or *ptr > '9'){
    						machine->WriteRegister(2, 0);
    						printf("\nThe integer number is not valid\n");
                            next_pc();                        
                            delete[] buffer;
                            return;
    					}
    					number = number * 10 + *ptr - '0';
    				}
                    if(is_negative)
                        number *= -1;
    				machine->WriteRegister(2, number);
                    delete[] buffer;
                    next_pc();
    				return;
    			}
    			case SC_PrintInt:{
                    char* buffer = new char[MAX_BUFFER + 1]; // khoi tao buffer
    				int length = 0; // chieu dai so nhap vao
    				int num = machine->ReadRegister(4); // doc so nhap vao
    				bool is_negative = false;
                    if(num == 0){
                        *buffer = '0';
                        length = 1;
                    }
                    else if(num < 0){
                        // la so am thi danh dau is_negative la true va bien so do thanh so duong
                        is_negative = true;
                        num *= -1;
                    }
                    // ghi cac chu so vao buffer theo chieu nguoc lai
                    // vd: so nhap vao la 12345 thi trong buffer hien tai la 54321
                    for(char* ptr = buffer; length <= 255 and num > 0;ptr++, length++, num /= 10)
                        *ptr = num % 10 + '0';
                    // dao chieu cho dung voi so nhap vao
                    for(char* left = buffer, *right = buffer + length - 1; left < right; left++, right--){
                        char tmp = *left;
                        *left = *right;
                        *right = tmp;
                    }
                    if(is_negative){
                        // neu la so am thi can ki tu - o dau
                        memcpy(buffer+1,buffer,length++); // doi cac ki tu sang phai 1 ki tu
                        *buffer = '-'; // ghi gia tri - vao ki tu dau tien
                    }
    				gSynchConsole->Write(buffer, length);
                    next_pc();
                    delete[] buffer;
    				return;
    			}
                case SC_ReadChar:{
                    char* buffer = new char[MAX_BUFFER + 1]; // khoi tao buffer
                    int length = gSynchConsole->Read(buffer,MAX_BUFFER); // so bytes thuc su doc duoc tu console
                    if(length != 1) // kiem tra chieu dai, char thi length se luon luon la 1
                    {
                        printf("\nThe input is not valid\n");
                        next_pc();                        
                        delete[] buffer;
                        return;
                    }
                    machine->WriteRegister(2, *buffer); // tra ve gia tri
                    next_pc();
                    delete[] buffer;
                    return;
                }
                case SC_PrintChar:{
                    // doc ki tu nhap vao, char luon luon la 1 nen khong can khoi tao buffer
                    char c = (char)machine->ReadRegister(4);
                    gSynchConsole->Write(&c,1); // ghi ra console
                    next_pc();
                    return;
                }
                case SC_ReadString:{
                    int user_buffer = machine->ReadRegister(4); // doc dia chi o user kernel
                    int length = machine->ReadRegister(5); // doc chieu dai chuoi
                    char* kernel_buffer = User2System(user_buffer,length); // copy sang system kernel
                    gSynchConsole->Read(kernel_buffer,length); // doc vao system kernel
                    System2User(user_buffer,length,kernel_buffer); // ghi nguoc ra user kernel
                    delete[] kernel_buffer;
                    next_pc();
                    return;
                }
                case SC_PrintString:{
                    int user_buffer = machine->ReadRegister(4); // doc dia chi o user kernel
                    char* kernel_buffer = User2System(user_buffer, MAX_BUFFER); // copy sang system kernel
                    // tinh chieu dai thuc su cua chuoi
                    int length = 0;
                    for(;kernel_buffer[length] != 0; length++)
                    {

                    }
                    gSynchConsole->Write(kernel_buffer, length+1); // in ra console
                    delete[] kernel_buffer;
                    next_pc();
                    return;
                }
    		}
    	}
    	
    	case PageFaultException:{
            printf("\nNo valid translation found %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case ReadOnlyException:{
            printf("\nWrite attempted to page marked \'read-only\' %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case BusErrorException:{
            printf("\nTranslation resulted invalid physical address %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case AddressErrorException:{
            printf("\nUnaligned reference or one that was beyond the end of the address space %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case OverflowException:{
            printf("\nInteger overflow in add or sub. %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case IllegalInstrException:{
            printf("\nUnimplemented or reserved instr. %d %d\n", which, type);
            interrupt->Halt();
    	}
    	case NumExceptionTypes:{
            printf("\nNumber exception types %d %d\n", which, type);
            interrupt->Halt();
    	}
    	default:{
            printf("\nUnexpected user mode exception %d %d\n", which, type);
            interrupt->Halt();
    	}
    }
}
