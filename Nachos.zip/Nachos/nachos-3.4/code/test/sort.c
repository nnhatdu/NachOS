#include "syscall.h"
int
main()
{
    int n, i, j, tmp, arr[100]; // khoi tao cac bien can thiet
    PrintString("Nhap kich thuoc mang: ");
    n = ReadInt(); // doc vao chieu dai cua mang
    if(n > 100 || n <= 0) // kiem tra tinh hop le
    {
        PrintString("Mang khong hop le\n");
        Halt();
    }
    for(i = 0; i < n; i++)
    {
        PrintString("Nhap so thu ");
        PrintInt(i);
        PrintString(": ");
        arr[i] = ReadInt(); // doc gia tri thu i cua mang
    }
    // sap xep theo thuat toan bubble sort
    for(i = 0; i < n; i++)
    {
        for(j = n-1; j > i; j--)
        {
            if(arr[j] < arr[j-1])
            {
                tmp = arr[j];
                arr[j] = arr[j-1];
                arr[j-1]=tmp;
            }
        }
    }
    // in ra cac phan tu trong mang theo thu tu tang dan
    PrintString("Mang sau khi sap xep: \n");
    for(i = 0; i < n; i++){
        PrintInt(arr[i]);
        PrintString("\n");
    }
    Halt();
}
