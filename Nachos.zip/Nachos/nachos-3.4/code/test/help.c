#include "syscall.h"

int main()
{
	// in ra thong tin cac thu bang ham PrintString
	PrintString("\t\tThong tin co ban\n");
	PrintString("19127057 - Tran Vinh Phat\n");
	PrintString("19127108 - Ngo Phu Chien\n");
	PrintString("19127120 - Ngo Nhat Du\n");
	PrintString("\n\n\t\tChuong trinh ascii\n");
	PrintString("Dau tien chuong trinh se goi syscall PrintString de in ra ten bang ascii\n, sau do lap tu 0 toi 127, in ra gia tri so ascii bang syscall PrintInt,\nin ra dau bang bang ham PrintString va in ra ky tu ascii bang ham PrintChar\n");
	PrintString("\n\n\t\tChuong trinh sort\n");
	PrintString("Chuong trinh sort dung syscall PrintString de in ra cac label la nhung thong bao,\nyeu cau de nguoi dung tuong tac voi chuong trinh, dau tien nguoi dung nhap \nso luong phan tu bang syscall ReadInt, sau do");
	PrintString("nhap cac phan tu bang syscall\n ReadInt, sau do dung thuat toan bubble sort de sap xep va dung ham PrintInt\nde in ra cac phan tu theo thu tu sap xep tang dan\n\n");
	Halt();	
}