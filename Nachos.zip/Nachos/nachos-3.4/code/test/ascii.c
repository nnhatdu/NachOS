#include "syscall.h"

void main()
{
	char c;
    int i, j;
    PrintString("\tASCII Table\n"); // in ra label
    for(i = 0; i < 16; i++)
    {
        for(j = 0; j < 8; j++)
        {
            c = i * 8 + j;
            PrintInt(c); // in ra ki tu ascii o dang so
            if(c < 10)
                PrintString("    =  ");
            else if(c < 100)
                PrintString("   =  ");
            else 
                PrintString("  =  ");
            PrintChar(c); // in ra ki tu ascii o dang char
            PrintString("   |   "); // xuong hang
        }
    	PrintString("\n");
    }
    Halt(); // ket thuc chuong trinh
}